﻿ # Resize partition based on drive letter
 ## Declare drive letter
 $DriveLetter = "C"
 ## Find maximum size of the partition based on drive letter
 $MaxSize = (Get-PartitionSupportedSize -DriveLetter $DriveLetter).SizeMax
 ## Resize the partition
 Resize-Partition -DriveLetter $DriveLetter -Size $MaxSize